package com.berenice.aws.cognito.jwt.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

/**
 * 
 * @author Berenice
 * 08.2019
 *
 */
@SpringBootApplication
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SampleCognitoApp {

	public static void main(String[] args) {
		SpringApplication.run(SampleCognitoApp.class, args);
	}
}
